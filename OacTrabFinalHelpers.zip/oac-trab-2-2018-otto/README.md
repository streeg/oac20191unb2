# oac-trab-2-2018

University of Brasilia

Computer Science

Computer Architecture and Organization - Project 2

Pipelining Operational Unit for MIPS 32 bits 

Members:

Otto

Victor Fabre

Victor Landim
